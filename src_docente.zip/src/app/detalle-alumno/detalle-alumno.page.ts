import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { Iasignatura, IAlumno } from 'src/interfaces/IAsignatura';
import { ApicrudService } from '../services/apicrud.service';
import { AlertController } from '@ionic/angular';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-detalle-alumno',
  templateUrl: './detalle-alumno.page.html',
  styleUrls: ['./detalle-alumno.page.scss'],
})
export class DetalleAlumnoPage implements OnInit {


  unAsignatura: any;
  qrdata:string;

  usuarios= {
    username: '',
    rut: '',
    email: '' 
  }

  id: any;


  asignatura={
    id: "",
    nombre: "",
    profesor: "",
    hora: "",
    fecha: "",
  }

  constructor(
    private activated: ActivatedRoute,
    private router: Router,
    private apicrud: ApicrudService,
    private alertcontroller: AlertController,
    private menucontroller: MenuController) {
      this.activated.queryParams.subscribe(params=>{
        this.unAsignatura = JSON.parse(params['asignatura'])
      })
      this.qrdata='';
      this.usuarios.username = sessionStorage.getItem('username') || 'Nombre no disponible';
      this.usuarios.rut = sessionStorage.getItem('rut') || 'RUT no disponible';

     }

  ngOnInit() {
    this.id = this.unAsignatura.id;
    this.asignatura=this.unAsignatura;
  }

  regresar(){
    this.router.navigate(['/tabs/tabs2']);
  }

  actualizarAsignatura(Observable:Iasignatura){
    this.router.navigate(['/actualizar', this.asignatura.id],
    {queryParams:{asignatura:JSON.stringify(Observable)}})
  }

  generarQr(){
    this.qrdata='';
    this.qrdata = `
    Nombre: ${this.usuarios.username}
    RUT: ${this.usuarios.rut}
    Asignatura: ${this.asignatura.nombre}
    Profesor: ${this.asignatura.profesor}
    Fecha: ${this.asignatura.fecha}
    Hora: ${this.asignatura.hora}
  `;
  console.log('QR Data:', this.qrdata);
}


  async consultaElimina(){
    const alert = await this.alertcontroller.create({
      header: 'Desea Eliminar?',
      message: 'Necesita eliminar la asignatura?',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
            this.router.navigate(['/tabs/tab1']);
          },
        },
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.eliminar();
          },
        },
      ],
    });

    await alert.present();
  }

  eliminar(){
    this.apicrud.deleteAsignatura(this.asignatura).subscribe();
    this.mensaje();
  }
  async mensaje(){
    const alert = await this.alertcontroller.create({
      header: 'Alumno Eliminado!',
      message: 'Sus Datos han sido Eliminado',
      buttons: [
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.router.navigate(['/tabs/tab1']);
          },
        },
      ],
    });

    await alert.present();

  }

  async mostrarMensaje(){
    const alerta = await this.alertcontroller.create({
      header:'Creando Palabra',
      message: 'Su QR ha sido Almacenado',
      buttons: ['Ok']
    })
    alerta.present();
  }

  mostrarMenu() {
    this.menucontroller.enable(true);
    this.menucontroller.open('first');
  }

  irAJustificarAsistencia() {
    this.router.navigate(['/justificar-asistencia']);
  }
}