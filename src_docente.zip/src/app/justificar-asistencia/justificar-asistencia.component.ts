import { Component, OnInit } from '@angular/core';

// Definimos el tipo de las asignaturas y los profesores
type Asignatura = 'Arquitectura de Software' | 'Estadística Descriptiva' | 'Ética Profesional' | 'Programación de Aplicaciones Móviles';

@Component({
  selector: 'app-justificar-asistencia',
  templateUrl: './justificar-asistencia.component.html',
  styleUrls: ['./justificar-asistencia.component.scss']
})
export class JustificarAsistenciaComponent implements OnInit {

  justificacionesGuardadas: any[] = [];
  comentariosGuardados: string[] = [];
  nuevoComentario: string = '';

  constructor() {}

  ngOnInit(): void {
    this.cargarJustificaciones();
    this.cargarComentarios();
  }

  cargarJustificaciones() {
    const justificaciones = localStorage.getItem('justificaciones');
    this.justificacionesGuardadas = justificaciones ? JSON.parse(justificaciones) : [];
  }

  enviarComentario() {
    if (this.nuevoComentario.trim() !== '') {
      this.comentariosGuardados.push(this.nuevoComentario.trim());
      this.guardarComentarios();
      this.nuevoComentario = ''; // Limpiar el campo de texto
    } else {
      alert('Por favor, escribe un comentario antes de enviarlo.');
    }
  }

  guardarComentarios() {
    localStorage.setItem('comentarios', JSON.stringify(this.comentariosGuardados));
  }

  cargarComentarios() {
    const comentarios = localStorage.getItem('comentarios');
    this.comentariosGuardados = comentarios ? JSON.parse(comentarios) : [];
  }

  editarComentario(comentario: string) {
    this.nuevoComentario = comentario; // Rellenamos el campo de nuevoComentario con el comentario a editar
    this.comentariosGuardados = this.comentariosGuardados.filter(c => c !== comentario); // Eliminar el comentario que vamos a editar
  }

  eliminarComentario(comentario: string) {
    this.comentariosGuardados = this.comentariosGuardados.filter(c => c !== comentario); // Eliminar el comentario seleccionado
    this.guardarComentarios();
  }
}