import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AutorizadoGuard } from './guards/autorizado.guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'comienzo',
    pathMatch: 'full'
  },
  {
    path: '',
    loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule)
  },
  {
    path: 'comienzo',
    loadChildren: () => import('./comienzo/comienzo.module').then(m => m.ComienzoPageModule)
  },
  {
    path: 'registro',
    loadChildren: () => import('./registro/registro.module').then(m => m.RegistroPageModule),
    canActivate: [AutorizadoGuard]
  },
  {
    path: 'detalle-alumno',
    loadChildren: () => import('./detalle-alumno/detalle-alumno.module').then(m => m.DetalleAlumnoPageModule),
    canActivate: [AutorizadoGuard]
  },
  {
    path: 'actualizar/:id',
    loadChildren: () => import('./actualizar/actualizar.module').then(m => m.ActualizarPageModule),
    canActivate: [AutorizadoGuard]
  },
  {
    path: 'justificar-asistencia',
    loadChildren: () => import('./justificar-asistencia/justificar-asistencia.module').then(m => m.JustificarAsistenciaPageModule)
  },
  {
    path: 'crear-usuario',
    loadChildren: () => import('./crear-usuario/crear-usuario.module').then(m => m.CrearUsuarioPageModule)
  },
  {
    path: 'configuracion-perfil',
    loadChildren: () => import('./configuracion-perfil/configuracion-perfil.module').then( m => m.ConfiguracionPerfilPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
