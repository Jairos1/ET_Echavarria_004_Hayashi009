import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page implements OnInit {


  imageSrc: string | ArrayBuffer | null = null;
  username: string ='';
  rut: string ='';
  nombre: string ='';
  apellido: string ='';
  password: string ='';
  email: string ='';
  mostrarPassword: boolean = false;

  constructor(private router: Router){}

  ngOnInit(){
    this.imageSrc = localStorage.getItem('photo');
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras.state) {
      this.imageSrc = navigation.extras.state['imageSrc'] || null;
    }
    
    this.username = sessionStorage.getItem('username') || 'Sin usuario';
    this.rut = sessionStorage.getItem('rut') || 'Sin RUT';
    this.nombre = sessionStorage.getItem('nombre') || 'Sin nombre';
    this.apellido = sessionStorage.getItem('apellido') || 'Sin apellido';
    this.password = sessionStorage.getItem('password') || '******';
    this.email = sessionStorage.getItem('email') || 'Sin correo';
  }
  
  togglePasswordVisibility() {
    this.mostrarPassword = !this.mostrarPassword;
  }

  actualizarUsuario() {
    this.router.navigate(['/configuracion-perfil']);
  }

  onImageSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imageSrc = reader.result; // Asigna la imagen seleccionada
      };
      reader.readAsDataURL(file);
    }
  }
}