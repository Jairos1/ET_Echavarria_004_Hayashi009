import { Component } from '@angular/core';
import { AlertController, NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http'; 
import { Users } from '../../interfaces/users';  

@Component({
  selector: 'app-recover-password',
  templateUrl: './recover-password.page.html',
  styleUrls: ['./recover-password.page.scss'],
})
export class RecoverPasswordPage {
  email: string = '';  
  usuarios: Users[] = [];  
  constructor(
    private alertController: AlertController, 
    private navCtrl: NavController, 
    private http: HttpClient  
  ) {}

  ngOnInit() {

    this.http.get<any>('../../data/almacen.json').subscribe(
      (data) => {
        console.log('Usuarios cargados:', data.usuarios);  
        this.usuarios = data.usuarios;
      },
      (error) => {
        console.error('Error al cargar el archivo JSON:', error);
      }
    );
  }

  async recoverPassword() {
    console.log('Email ingresado:', this.email); 
    const user: Users | undefined = this.usuarios.find((u: Users) => u.email === this.email.toLowerCase());

    if (!user) {
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'El correo ingresado no se encuentra registrado.',
        buttons: ['OK']
      });
      await alert.present();
    } else {
      const alert = await this.alertController.create({
        header: 'Éxito',
        message: 'Se ha enviado un enlace para cambiar tu contraseña (simulado).',
        buttons: [
          {
            text: 'OK',
            handler: () => {
              this.navCtrl.navigateForward('/reset-password');
            }
          }
        ]
      });
      await alert.present();
    }
  }
}
