import { Component } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';  // Importa HttpClient para obtener el JSON
import { Users } from '../../interfaces/users';  // Asegúrate de que esta ruta sea correcta

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.page.html',
  styleUrls: ['./reset-password.page.scss'],
})
export class ResetPasswordPage {
  newPassword: string = '';
  confirmPassword: string = '';
  email: string = ''; 
  usuarios: Users[] = [];  
  
  constructor(private alertController: AlertController, private http: HttpClient) {}

  ngOnInit() {
    this.http.get<any>('../../data/almacen.json').subscribe((data) => {
      this.usuarios = data.usuarios; 
    });
  }

  async updatePassword() {
 
    if (this.newPassword !== this.confirmPassword) {
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'Las contraseñas no coinciden.',
        buttons: ['OK']
      });
      await alert.present();
      return;
    }


    const userIndex = this.usuarios.findIndex((u: Users) => u.email === this.email);
    if (userIndex !== -1) {
     
      this.usuarios[userIndex].password = this.newPassword;

      
      const alert = await this.alertController.create({
        header: 'Éxito',
        message: 'Tu contraseña ha sido actualizada.',
        buttons: ['OK']
      });
      await alert.present();
    } else {
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'No se encontró el usuario.',
        buttons: ['OK']
      });
      await alert.present();
    }
  }
}
