import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApicrudService } from '../services/apicrud.service';
import { MenuController } from '@ionic/angular';


@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit {
 
  postsos: any[] = [];  
  usuario: any;

  constructor(
    private router: Router, 
    private apidato: ApicrudService, 
    private menucontroller: MenuController
  ) {}

  ngOnInit(): void {
    this.usuario = sessionStorage.getItem('username');
    console.log(this.usuario);
  }

  mostrarMenu() {
    this.menucontroller.enable(true);
    this.menucontroller.open('first');
  }
}
